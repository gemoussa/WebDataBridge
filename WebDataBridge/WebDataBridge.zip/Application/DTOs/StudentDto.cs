﻿namespace WebDataBridge.Application.DTOs
{
    public class StudentDto
    {
        public int id { get; set; }
        public string? name { get; set; }
        public string? address { get; set; }
        public int age { get; set; }
        
    }
}
